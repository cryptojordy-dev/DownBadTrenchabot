import os
import requests
import time
from datetime import datetime, timezone

# ─── CONFIG ───────────────────────────────────────────────
BOT_TOKEN           = os.environ.get("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
CHAT_ID             = os.environ.get("CHAT_ID", "YOUR_CHAT_ID_HERE")
ALERT_THRESHOLD_PCT = 5.0
CHECK_INTERVAL      = 60
MARKET_DIGEST_SECS  = 43200
WHALE_MIN_USD       = 5_000_000
# ──────────────────────────────────────────────────────────

BASE_URL = f"https://api.telegram.org/bot{BOT_TOKEN}"

CRYPTO_COINS = {
    "bitcoin":     "BTC",
    "ethereum":    "ETH",
    "solana":      "SOL",
    "hyperliquid": "HYPE",
    "sonic-svm":   "SONIC",
}

TRAD_SYMBOLS = {
    "GC=F":  "Gold",
    "SI=F":  "Silver",
    "^GSPC": "S&P500",
}

# Known insider / smart money wallets to track
INSIDER_WALLETS = {
    # BTC wallets
    "bitcoin": {
        "1P5ZEDWTKTFGxQjZphgWPQUpe554WKDfHQ": "Binance Cold Wallet",
        "34xp4vRoCGJym3xR7yCVPFHoCNxv4Twseo": "Binance Hot Wallet",
        "bc1qgdjqv0av3q56jvd82tkdjpy7gdp9ut8tlqmgrpmv24sq90ecnvqqjwvw97": "MicroStrategy",
        "1FeexV6bAHb8ybZjqQMjJrcCrHGW9sb6uF": "Unknown OG Whale (lost?)",
    },
    # ETH wallets
    "ethereum": {
        "0x47ac0Fb4F2D84898e4D9E7b4DaB3C24507a6D503": "Binance ETH Wallet",
        "0xBE0eB53F46cd790Cd13851d5EFf43D12404d33E8": "Binance Cold Wallet 2",
        "0x40B38765696e3d5d8d9d834D8AaD4bB6e418E489": "Robinhood",
        "0x28C6c06298d514Db089934071355E5743bf21d60": "Binance Hot Wallet 2",
        "0xab5801a7d398351b8be11c439e05c5b3259aec9b": "Vitalik Buterin",
    }
}

previous_prices  = {}
user_alerts      = {}
last_digest_time = 0

SYMBOL_MAP = {
    "btc": "bitcoin", "eth": "ethereum", "sol": "solana",
    "hype": "hyperliquid", "sonic": "sonic-svm",
    "gold": "GC=F", "silver": "SI=F", "sp500": "^GSPC", "spx": "^GSPC"
}

# ─── TELEGRAM ────────────────────────────────────────────

def send_message(text, parse_mode="Markdown"):
    try:
        requests.post(f"{BASE_URL}/sendMessage", json={
            "chat_id": CHAT_ID,
            "text": text,
            "parse_mode": parse_mode
        }, timeout=10)
    except Exception as e:
        print(f"Telegram error: {e}")

# ─── PRICES ──────────────────────────────────────────────

def get_crypto_prices():
    try:
        r = requests.get(
            "https://api.coingecko.com/api/v3/simple/price",
            params={"ids": ",".join(CRYPTO_COINS.keys()), "vs_currencies": "usd", "include_24hr_change": "true"},
            timeout=10
        )
        return r.json()
    except:
        return {}

def get_yahoo_price(symbol):
    try:
        r = requests.get(
            f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}",
            headers={"User-Agent": "Mozilla/5.0"}, timeout=10
        )
        meta = r.json()["chart"]["result"][0]["meta"]
        price = meta.get("regularMarketPrice", 0)
        prev  = meta.get("previousClose", price)
        return price, ((price - prev) / prev * 100) if prev else 0
    except:
        return None, None

def format_prices_message():
    lines = ["📊 *DownBadTrenchBot — Live Prices*\n"]
    lines.append("*— Crypto —*")
    for coin_id, symbol in CRYPTO_COINS.items():
        info = get_crypto_prices().get(coin_id, {})
        price = info.get("usd")
        change = info.get("usd_24h_change")
        if price is not None:
            arrow = "🟢" if change >= 0 else "🔴"
            lines.append(f"{arrow} *{symbol}*: `${price:,.4f}`  ({change:+.2f}%)")
        else:
            lines.append(f"⚪ *{symbol}*: unavailable")
    lines.append("\n*— Traditional Markets —*")
    for symbol, name in TRAD_SYMBOLS.items():
        price, change = get_yahoo_price(symbol)
        if price:
            arrow = "🟢" if change >= 0 else "🔴"
            lines.append(f"{arrow} *{name}*: `${price:,.2f}`  ({change:+.2f}%)")
        else:
            lines.append(f"⚪ *{name}*: unavailable")
    lines.append(f"\n_Updated: {datetime.now(timezone.utc).strftime('%H:%M:%S UTC')}_")
    return "\n".join(lines)

# ─── DOMINANCE ───────────────────────────────────────────

def get_dominance():
    try:
        r = requests.get("https://api.coingecko.com/api/v3/global", timeout=10)
        data = r.json()["data"]
        dom  = data.get("market_cap_percentage", {})
        total_mcap = data.get("total_market_cap", {}).get("usd", 0)
        total_vol  = data.get("total_volume", {}).get("usd", 0)
        change_24h = data.get("market_cap_change_percentage_24h_usd", 0)

        btc  = dom.get("btc", 0)
        eth  = dom.get("eth", 0)
        usdt = dom.get("usdt", 0)
        usdc = dom.get("usdc", 0)
        bnb  = dom.get("bnb", 0)
        others = 100 - btc - eth - usdt - usdc - bnb

        stablecoin_dom = usdt + usdc

        # BTC dominance sentiment
        if btc > 60:
            btc_signal = "🐻 Alt season far — BTC heavily dominant"
        elif btc > 55:
            btc_signal = "⚠️ BTC dominant — alts struggling"
        elif btc > 50:
            btc_signal = "😐 Neutral — potential alt rotation building"
        else:
            btc_signal = "🚀 Alt season territory — BTC dominance low"

        lines = [
            "📊 *Market Dominance*\n",
            f"🟠 *BTC*:  `{btc:.1f}%`",
            f"🔵 *ETH*:  `{eth:.1f}%`",
            f"🟢 *Stablecoins*:  `{stablecoin_dom:.1f}%`  (USDT `{usdt:.1f}%` + USDC `{usdc:.1f}%`)",
            f"🟡 *BNB*:  `{bnb:.1f}%`",
            f"⚫ *Others*:  `{others:.1f}%`",
            f"\n💰 Total Market Cap: `${total_mcap/1e12:.2f}T`  ({change_24h:+.2f}% 24h)",
            f"📈 24h Volume: `${total_vol/1e9:.1f}B`",
            f"\n_{btc_signal}_"
        ]
        return "\n".join(lines)
    except Exception as e:
        return f"Could not fetch dominance: {e}"

# ─── HEATMAP ─────────────────────────────────────────────

def get_heatmap():
    try:
        r = requests.get(
            "https://api.coingecko.com/api/v3/coins/markets",
            params={"vs_currency": "usd", "order": "market_cap_desc",
                    "per_page": 30, "page": 1, "price_change_percentage": "24h"},
            timeout=15
        )
        coins = r.json()

        lines = [f"🌡 *Market Heatmap — Top 30 by MCap*\n_{datetime.now(timezone.utc).strftime('%H:%M UTC')}_\n"]

        for coin in coins:
            sym    = coin.get("symbol","?").upper()
            chg    = coin.get("price_change_percentage_24h") or 0
            price  = coin.get("current_price", 0)
            mcap   = coin.get("market_cap", 0)

            if chg >= 10:
                emoji = "🟢🟢"
            elif chg >= 5:
                emoji = "🟢"
            elif chg >= 2:
                emoji = "🔼"
            elif chg >= 0:
                emoji = "🟡"
            elif chg >= -2:
                emoji = "🔽"
            elif chg >= -5:
                emoji = "🔴"
            else:
                emoji = "🔴🔴"

            mcap_str = f"${mcap/1e9:.1f}B" if mcap >= 1e9 else f"${mcap/1e6:.0f}M"
            lines.append(f"{emoji} *{sym:<6}* `{chg:+.1f}%`  `${price:,.3f}`  _{mcap_str}_")

        return "\n".join(lines)
    except Exception as e:
        return f"Could not fetch heatmap: {e}"

# ─── DEX TRENDING (GeckoTerminal) ────────────────────────

DEX_NETWORKS = [
    ("solana",   "Solana"),
    ("eth",      "Ethereum"),
    ("base",     "Base"),
]

def get_dex_trending():
    lines = [f"💧 *DEX Trending Pools — GeckoTerminal*\n_{datetime.now(timezone.utc).strftime('%H:%M UTC')}_\n"]

    for network, label in DEX_NETWORKS:
        try:
            r = requests.get(
                f"https://api.geckoterminal.com/api/v2/networks/{network}/trending_pools",
                params={"include": "base_token,dex"},
                headers={"Accept": "application/json;version=20230302"},
                timeout=10
            )
            pools = r.json().get("data", [])[:4]
            lines.append(f"*— {label} —*")

            for pool in pools:
                attr   = pool.get("attributes", {})
                name   = attr.get("name", "?")
                price  = float(attr.get("base_token_price_usd", 0) or 0)
                vol24  = float(attr.get("volume_usd", {}).get("h24", 0) or 0)
                chg1h  = float(attr.get("price_change_percentage", {}).get("h1", 0) or 0)
                chg24  = float(attr.get("price_change_percentage", {}).get("h24", 0) or 0)
                buys   = attr.get("transactions", {}).get("h1", {}).get("buys", 0)
                sells  = attr.get("transactions", {}).get("h1", {}).get("sells", 0)

                arrow24 = "🟢" if chg24 >= 0 else "🔴"
                vol_str = f"${vol24/1e6:.1f}M" if vol24 >= 1e6 else f"${vol24/1e3:.0f}K"

                lines.append(
                    f"{arrow24} *{name}*\n"
                    f"   Price: `${price:,.6f}`  •  Vol 24h: `{vol_str}`\n"
                    f"   1h: `{chg1h:+.2f}%`  24h: `{chg24:+.2f}%`  •  Buys/Sells: `{buys}/{sells}`"
                )
            lines.append("")
        except Exception as e:
            lines.append(f"*— {label} —*\n_Error: {e}_\n")

    return "\n".join(lines)

# ─── CATEGORY TOKENS (Privacy & AI) ─────────────────────

def get_category_tokens(category_id, label, emoji, limit=5):
    """Fetch top tokens by 24h % change within a CoinGecko category."""
    try:
        r = requests.get(
            "https://api.coingecko.com/api/v3/coins/markets",
            params={
                "vs_currency": "usd",
                "category": category_id,
                "order": "volume_desc",
                "per_page": 20,
                "page": 1,
                "price_change_percentage": "24h",
            },
            timeout=12
        )
        coins = [c for c in r.json() if c.get("total_volume", 0) > 100_000]
        # Sort by absolute 24h change to show most active movers
        coins_sorted = sorted(coins, key=lambda x: abs(x.get("price_change_percentage_24h") or 0), reverse=True)
        top = coins_sorted[:limit]

        lines = [f"{emoji} *Top {limit} Trending {label} Tokens*\n_{datetime.now(timezone.utc).strftime('%d %b • %H:%M UTC')}_\n"]

        for i, coin in enumerate(top, 1):
            name   = coin.get("name", "?")
            sym    = coin.get("symbol", "?").upper()
            price  = coin.get("current_price", 0)
            chg    = coin.get("price_change_percentage_24h") or 0
            mcap   = coin.get("market_cap", 0)
            vol    = coin.get("total_volume", 0)
            rank   = coin.get("market_cap_rank", "N/A")

            arrow  = "🟢" if chg >= 0 else "🔴"
            mcap_s = f"${mcap/1e9:.2f}B" if mcap >= 1e9 else f"${mcap/1e6:.1f}M"
            vol_s  = f"${vol/1e6:.1f}M"

            # Price formatting — handle micro-cap prices
            if price >= 1:
                price_s = f"${price:,.2f}"
            elif price >= 0.001:
                price_s = f"${price:,.4f}"
            else:
                price_s = f"${price:.2e}"

            lines.append(
                f"{i}. {arrow} *{sym}* — {name}  _(#{rank})_\n"
                f"   Price: `{price_s}`  •  24h: `{chg:+.2f}%`\n"
                f"   MCap: `{mcap_s}`  •  Vol: `{vol_s}`\n"
            )

        return "\n".join(lines)
    except Exception as e:
        return f"Could not fetch {label} tokens: {e}"

def get_privacy_tokens():
    return get_category_tokens("privacy-coins", "Privacy", "🕵️", limit=5)

def get_ai_tokens():
    return get_category_tokens("artificial-intelligence", "AI", "🤖", limit=5)

# ─── INSIDERS (Blockchair wallet tracker) ─────────────────

def get_insider_activity():
    lines = [f"🕵️ *Insider Wallet Activity*\n_{datetime.now(timezone.utc).strftime('%H:%M UTC')}_\n"]
    found_any = False

    # ETH wallets via Blockchair
    lines.append("*— Ethereum Wallets —*")
    for address, label in INSIDER_WALLETS["ethereum"].items():
        try:
            r = requests.get(
                f"https://api.blockchair.com/ethereum/dashboards/address/{address}",
                params={"transaction_details": "true"},
                timeout=10
            )
            data = r.json().get("data", {}).get(address.lower(), {})
            addr_data = data.get("address", {})
            balance_eth = int(addr_data.get("balance", 0)) / 1e18
            txs = data.get("transactions", [])
            recent_tx = txs[0] if txs else None

            bal_str = f"{balance_eth:,.2f} ETH"
            short_addr = address[:8] + "..." + address[-6:]

            if recent_tx:
                found_any = True
                lines.append(
                    f"🏦 *{label}*\n"
                    f"   `{short_addr}`\n"
                    f"   Balance: `{bal_str}`\n"
                    f"   Last tx: `{str(recent_tx)[:20]}...`"
                )
            else:
                lines.append(f"🏦 *{label}*: `{bal_str}`  _(no recent txs)_")
        except Exception as e:
            lines.append(f"🏦 *{label}*: _error fetching_")

    # BTC wallets via Blockchair
    lines.append("\n*— Bitcoin Wallets —*")
    for address, label in INSIDER_WALLETS["bitcoin"].items():
        try:
            r = requests.get(
                f"https://api.blockchair.com/bitcoin/dashboards/address/{address}",
                timeout=10
            )
            data = r.json().get("data", {}).get(address, {})
            addr_data = data.get("address", {})
            balance_btc = int(addr_data.get("balance", 0)) / 1e8
            tx_count = addr_data.get("transaction_count", 0)
            short_addr = address[:8] + "..."

            lines.append(
                f"🏦 *{label}*\n"
                f"   `{short_addr}`\n"
                f"   Balance: `{balance_btc:,.2f} BTC`  •  Txs: `{tx_count:,}`"
            )
            found_any = True
        except:
            lines.append(f"🏦 *{label}*: _error fetching_")

    if not found_any:
        lines.append("_No recent activity detected_")

    lines.append(f"\n_Tip: Use `/addinsider <address> <label>` to track custom wallets_")
    return "\n".join(lines)

# ─── FEAR & GREED ────────────────────────────────────────

def get_fear_greed():
    try:
        r = requests.get("https://api.alternative.me/fng/?limit=1", timeout=10)
        data = r.json()["data"][0]
        value = int(data["value"])
        label = data["value_classification"]
        if value <= 20:   emoji = "😱"
        elif value <= 40: emoji = "😰"
        elif value <= 60: emoji = "😐"
        elif value <= 80: emoji = "😊"
        else:             emoji = "🤑"
        bar = "█" * round(value / 10) + "░" * (10 - round(value / 10))
        return "\n".join([
            "😱 *Crypto Fear & Greed Index*\n",
            f"{emoji} *{label}*",
            f"`{bar}` {value}/100",
            f"\n_0 = Extreme Fear → 100 = Extreme Greed_"
        ])
    except Exception as e:
        return f"Could not fetch Fear & Greed: {e}"

# ─── WHALE TXS (Blockchair) ──────────────────────────────

def format_whale_message():
    results = []
    for chain, symbol in [("bitcoin", "BTC"), ("ethereum", "ETH")]:
        try:
            r = requests.get(
                f"https://api.blockchair.com/{chain}/transactions",
                params={"s": "value(desc)", "limit": 5, "q": "time(1 hour ago..)"},
                timeout=12
            )
            for tx in r.json().get("data", []):
                usd_val = tx.get("output_total_usd" if chain == "bitcoin" else "value_usd", 0)
                amount  = tx.get("output_total" if chain == "bitcoin" else "value", 0)
                divisor = 1e8 if chain == "bitcoin" else 1e18
                if usd_val and usd_val >= WHALE_MIN_USD:
                    results.append({
                        "symbol": symbol, "usd": usd_val,
                        "amount": f"{amount/divisor:,.2f} {symbol}",
                        "hash": tx.get("hash","")[:10] + "...",
                        "time": tx.get("time","")[:16],
                    })
        except Exception as e:
            print(f"Whale error ({chain}): {e}")

    results.sort(key=lambda x: x["usd"], reverse=True)
    lines = [f"🐋 *Whale Transactions (Last Hour, >${WHALE_MIN_USD/1e6:.0f}M+)*\n"]
    if not results:
        lines.append("_No whale transactions above threshold right now._")
    else:
        for tx in results[:8]:
            usd_fmt = f"${tx['usd']/1e6:.1f}M"
            lines.append(f"🐋 *{tx['symbol']}* `{tx['amount']}`  (`{usd_fmt}`)\n   `{tx['hash']}`  •  _{tx['time']}_\n")
    lines.append(f"_Updated: {datetime.now(timezone.utc).strftime('%H:%M UTC')}_")
    return "\n".join(lines)

# ─── NEWS ────────────────────────────────────────────────

def get_crypto_news():
    try:
        r = requests.get("https://api.coingecko.com/api/v3/news", timeout=10)
        articles = r.json().get("data", [])[:7]
        lines = [f"📰 *Latest Crypto News*\n_{datetime.now(timezone.utc).strftime('%d %b • %H:%M UTC')}_\n"]
        for i, a in enumerate(articles, 1):
            title = a.get("title","?")
            site  = a.get("news_site","?")
            url   = a.get("url","")
            try:
                t = datetime.utcfromtimestamp(int(a.get("updated_at","0"))).strftime("%H:%M")
            except:
                t = ""
            lines.append(f"{i}. [{title}]({url})\n   _{site}_{' • _' + t + '_' if t else ''}\n")
        return "\n".join(lines)
    except Exception as e:
        return f"Could not fetch news: {e}"

# ─── MARKET DIGEST ───────────────────────────────────────

def get_top_gainer_loser():
    try:
        r = requests.get(
            "https://api.coingecko.com/api/v3/coins/markets",
            params={"vs_currency": "usd", "order": "market_cap_desc", "per_page": 250,
                    "page": 1, "price_change_percentage": "24h"}, timeout=15
        )
        coins  = [c for c in r.json() if c.get("total_volume", 0) > 1_000_000]
        by_asc = sorted(coins, key=lambda x: x.get("price_change_percentage_24h") or 0)
        by_desc= sorted(coins, key=lambda x: x.get("price_change_percentage_24h") or 0, reverse=True)
        return by_desc[0] if by_desc else None, by_asc[0] if by_asc else None
    except:
        return None, None

def get_trending_coins():
    try:
        r = requests.get("https://api.coingecko.com/api/v3/search/trending", timeout=10)
        return r.json().get("coins", [])[:7]
    except:
        return []

def get_new_coins():
    try:
        r = requests.get("https://api.coingecko.com/api/v3/coins/list/new", timeout=10)
        return r.json()[:5]
    except:
        return []

def build_market_digest():
    lines = [f"🌐 *DownBadTrenchBot — Market Digest*\n_{datetime.now(timezone.utc).strftime('%d %b %Y • %H:%M UTC')}_\n"]
    gainer, loser = get_top_gainer_loser()

    lines.append("*📈 Top Winner (24h)*")
    if gainer:
        chg = gainer.get("price_change_percentage_24h", 0)
        lines.append(f"🟢 *{gainer['symbol'].upper()}* — {gainer['name']}")
        lines.append(f"   `${gainer['current_price']:,.4f}`  •  `+{chg:.2f}%`")
    lines.append("\n*📉 Biggest Loser (24h)*")
    if loser:
        chg = loser.get("price_change_percentage_24h", 0)
        lines.append(f"🔴 *{loser['symbol'].upper()}* — {loser['name']}")
        lines.append(f"   `${loser['current_price']:,.4f}`  •  `{chg:.2f}%`")

    lines.append("\n*🔥 Trending*")
    for i, item in enumerate(get_trending_coins(), 1):
        c = item.get("item", {})
        sym = c.get("symbol","?").upper(); name = c.get("name","?"); rank = c.get("market_cap_rank","N/A")
        pdata = c.get("data", {}); p = pdata.get("price","")
        chg = pdata.get("price_change_percentage_24h",{}).get("usd",None)
        p_str = f"`${float(p):,.4f}`" if p else ""
        c_str = f" `{chg:+.2f}%`" if chg is not None else ""
        lines.append(f"{i}. *{sym}* — {name}  {p_str}{c_str} _(#{rank})_")

    lines.append("\n*✨ New Listings*")
    for coin in get_new_coins():
        sym = coin.get("symbol","?").upper(); name = coin.get("name","?")
        try:
            dt = datetime.utcfromtimestamp(coin.get("activated_at","")).strftime("%d %b")
            lines.append(f"• *{sym}* — {name} _(listed {dt})_")
        except:
            lines.append(f"• *{sym}* — {name}")

    lines.append(""); lines.append(get_fear_greed())
    return "\n".join(lines)

# ─── ALERT LOGIC ─────────────────────────────────────────

def _check_user_targets(key, label, price):
    if key not in user_alerts: return
    targets = user_alerts[key]
    if "above" in targets and price >= targets["above"]:
        send_message(f"🎯 *{label}* hit target! Now `${price:,.4f}` (above `${targets['above']:,.4f}`)")
        del user_alerts[key]["above"]
    if "below" in targets and price <= targets["below"]:
        send_message(f"🎯 *{label}* hit target! Now `${price:,.4f}` (below `${targets['below']:,.4f}`)")
        del user_alerts[key]["below"]

def check_alerts():
    crypto_data = get_crypto_prices()
    for coin_id, symbol in CRYPTO_COINS.items():
        price = crypto_data.get(coin_id, {}).get("usd")
        if not price: continue
        prev = previous_prices.get(coin_id)
        if prev and prev > 0:
            pct = ((price - prev) / prev) * 100
            if abs(pct) >= ALERT_THRESHOLD_PCT:
                send_message(f"⚠️ *{symbol}* {'🚀 surged' if pct>0 else '📉 dropped'} `{pct:+.2f}%` → `${price:,.4f}`")
        _check_user_targets(coin_id, symbol, price)
        previous_prices[coin_id] = price
    for yf_symbol, name in TRAD_SYMBOLS.items():
        price, _ = get_yahoo_price(yf_symbol)
        if not price: continue
        prev = previous_prices.get(yf_symbol)
        if prev and prev > 0:
            pct = ((price - prev) / prev) * 100
            if abs(pct) >= ALERT_THRESHOLD_PCT:
                send_message(f"⚠️ *{name}* {'🚀 surged' if pct>0 else '📉 dropped'} `{pct:+.2f}%` → `${price:,.2f}`")
        _check_user_targets(yf_symbol, name, price)
        previous_prices[yf_symbol] = price

# ─── COMMAND HANDLER ─────────────────────────────────────

def handle_commands(updates, last_update_id):
    for update in updates:
        uid = update["update_id"]
        if uid <= last_update_id: continue
        last_update_id = uid
        text = update.get("message", {}).get("text", "").strip()

        if text in ("/start", "/prices"):
            send_message("⏳ Fetching prices..."); send_message(format_prices_message())
        elif text == "/digest":
            send_message("⏳ Building digest..."); send_message(build_market_digest())
        elif text == "/fear":
            send_message(get_fear_greed())
        elif text == "/whales":
            send_message("⏳ Scanning blockchain..."); send_message(format_whale_message())
        elif text == "/news":
            send_message("⏳ Fetching news..."); send_message(get_crypto_news())
        elif text == "/dominance":
            send_message("⏳ Fetching dominance..."); send_message(get_dominance())
        elif text == "/heatmap":
            send_message("⏳ Building heatmap..."); send_message(get_heatmap())
        elif text == "/dex":
            send_message("⏳ Scanning DEX pools..."); send_message(get_dex_trending())
        elif text == "/privacy":
            send_message("⏳ Fetching privacy tokens..."); send_message(get_privacy_tokens())
        elif text == "/ai":
            send_message("⏳ Fetching AI tokens..."); send_message(get_ai_tokens())
        elif text == "/defi":
            send_message("⏳ Fetching DeFi tokens..."); send_message(get_category_tokens("decentralized-finance-defi", "DeFi", "⚡", limit=5))
        elif text == "/meme":
            send_message("⏳ Fetching meme coins..."); send_message(get_category_tokens("meme-token", "Meme", "🐸", limit=5))
        elif text == "/insiders":
            send_message("⏳ Checking insider wallets..."); send_message(get_insider_activity())
        elif text == "/trending":
            send_message("⏳ Fetching trending...")
            trending = get_trending_coins()
            lines = ["🔥 *Trending on CoinGecko*\n"]
            for i, item in enumerate(trending, 1):
                c = item.get("item", {})
                sym = c.get("symbol","?").upper(); name = c.get("name","?"); rank = c.get("market_cap_rank","N/A")
                pdata = c.get("data",{}); p = pdata.get("price","")
                chg = pdata.get("price_change_percentage_24h",{}).get("usd",None)
                p_str = f"`${float(p):,.4f}`" if p else ""
                c_str = f" `{chg:+.2f}%`" if chg is not None else ""
                lines.append(f"{i}. *{sym}* — {name}  {p_str}{c_str} _(#{rank})_")
            send_message("\n".join(lines))
        elif text == "/winners":
            send_message("⏳ Finding top movers...")
            gainer, loser = get_top_gainer_loser()
            lines = ["📈 *Top Winner & Loser — 24h*\n"]
            if gainer:
                chg = gainer.get("price_change_percentage_24h", 0)
                lines.append(f"🟢 *{gainer['name']}* ({gainer['symbol'].upper()})\n   `${gainer['current_price']:,.4f}`  `+{chg:.2f}%`")
            if loser:
                chg = loser.get("price_change_percentage_24h", 0)
                lines.append(f"\n🔴 *{loser['name']}* ({loser['symbol'].upper()})\n   `${loser['current_price']:,.4f}`  `{chg:.2f}%`")
            send_message("\n".join(lines))
        elif text == "/new":
            send_message("⏳ Fetching new listings...")
            lines = ["✨ *Newest CoinGecko Listings*\n"]
            for coin in get_new_coins():
                sym = coin.get("symbol","?").upper(); name = coin.get("name","?")
                try:
                    dt = datetime.utcfromtimestamp(coin.get("activated_at","")).strftime("%d %b %Y")
                    lines.append(f"• *{sym}* — {name} _(listed {dt})_")
                except:
                    lines.append(f"• *{sym}* — {name}")
            send_message("\n".join(lines))
        elif text == "/help":
            send_message(
                "🤖 *DownBadTrenchBot — Full Command List*\n\n"
                "📊 *Prices & Markets*\n"
                "/prices — Live watchlist prices\n"
                "/digest — Full auto market digest\n"
                "/winners — Top gainer & loser today\n"
                "/trending — Most searched coins\n"
                "/new — Newest listings\n"
                "/heatmap — 🌡 Top 30 coins visual heatmap\n"
                "/dominance — BTC/ETH/stablecoin dominance\n\n"
                "🧠 *Signals & Intelligence*\n"
                "/fear — Fear & Greed Index\n"
                "/whales — 🐋 Recent $5M+ on-chain txs\n"
                "/news — 📰 Latest crypto headlines\n"
                "/dex — 💧 Trending DEX pools (SOL/ETH/Base)\n"
                "/insiders — 🕵️ Known whale wallet activity\n"
                "/privacy — 🕵️ Top 5 trending privacy tokens\n"
                "/ai — 🤖 Top 5 trending AI tokens\n"
                "/defi — ⚡ Top 5 trending DeFi tokens\n"
                "/meme — 🐸 Top 5 trending meme coins\n\n"
                "🔔 *Alerts*\n"
                "/alert BTC above 70000\n"
                "/alerts — View active\n"
                "/clear — Clear all"
            )
        elif text.startswith("/alert"):
            parts = text.split()
            if len(parts) == 4:
                _, symbol, direction, target = parts
                key = SYMBOL_MAP.get(symbol.lower())
                if not key:
                    send_message(f"❌ Unknown: `{symbol}`")
                elif direction.lower() not in ("above", "below"):
                    send_message("❌ Use `above` or `below`")
                else:
                    try:
                        tp = float(target.replace(",",""))
                        if key not in user_alerts: user_alerts[key] = {}
                        user_alerts[key][direction.lower()] = tp
                        send_message(f"✅ Alert: *{symbol.upper()}* {direction} `${tp:,.2f}`")
                    except:
                        send_message("❌ Invalid price")
            else:
                send_message("❌ Format: `/alert BTC above 70000`")
        elif text == "/alerts":
            if not user_alerts:
                send_message("No active alerts.")
            else:
                lines = ["🔔 *Active Alerts*\n"]
                for key, targets in user_alerts.items():
                    label = next((v for k,v in {**CRYPTO_COINS,**TRAD_SYMBOLS}.items() if k==key), key.upper())
                    for direction, price in targets.items():
                        lines.append(f"• *{label}* {direction} `${price:,.2f}`")
                send_message("\n".join(lines))
        elif text == "/clear":
            user_alerts.clear(); send_message("🗑️ All alerts cleared.")

    return last_update_id

# ─── MAIN LOOP ───────────────────────────────────────────

def main():
    global last_digest_time
    print("🚀 DownBadTrenchBot running...")
    send_message(
        "🤖 *DownBadTrenchBot — Online*\n\n"
        "BTC • ETH • SOL • HYPE • SONIC • Gold • Silver • S\\&P500\n\n"
        "/prices /fear /whales /news\n"
        "/dominance /heatmap /dex /insiders\n"
        "/help — Full command list"
    )
    last_update_id = 0; last_price_check = 0
    last_digest_time = time.time()

    while True:
        try:
            r = requests.get(f"{BASE_URL}/getUpdates", params={"offset": last_update_id + 1}, timeout=10)
            updates = r.json().get("result", [])
            last_update_id = handle_commands(updates, last_update_id)
            now = time.time()
            if now - last_price_check >= CHECK_INTERVAL:
                check_alerts(); last_price_check = now
            if now - last_digest_time >= MARKET_DIGEST_SECS:
                send_message("⏰ *Auto 12h Market Digest*")
                send_message(build_market_digest())
                last_digest_time = now
        except Exception as e:
            print(f"Loop error: {e}")
        time.sleep(2)

if __name__ == "__main__":
    main()
