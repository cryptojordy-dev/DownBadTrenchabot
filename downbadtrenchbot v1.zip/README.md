# DownBadTrenchBot 🤖

A Telegram crypto bot tracking BTC, ETH, SOL, HYPE, SONIC, Gold, Silver, S&P500 + market intelligence.

## Commands
/prices /digest /winners /trending /new /heatmap /dominance
/fear /whales /news /dex /insiders /privacy /ai /defi /meme
/alert /alerts /clear /help

## Deploy on Railway
1. Push this repo to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Add environment variables:
   - BOT_TOKEN = your telegram bot token
   - CHAT_ID = your telegram chat id
4. Deploy — done!
